#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\DELL\Desktop\PRABHAS\flutter_windows_3.44.2-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\DSP\macro-snap-source-1.4.5\macro-snap-source-1.4.5"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\DSP\macro-snap-source-1.4.5\macro-snap-source-1.4.5\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.4.23"
export "FLUTTER_BUILD_NUMBER=36"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
